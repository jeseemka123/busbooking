// need to give backend url
const BASE_URL = "http://192.168.1.8/api/UserReg";
export { BASE_URL };
