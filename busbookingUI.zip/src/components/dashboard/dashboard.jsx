import React from 'react'

const Dashboard = () => {
  return (
    <div>
        <h1>Welcome to User</h1>
        <h1>Hi Siva</h1>
      
    </div>
  )
}

export default Dashboard

