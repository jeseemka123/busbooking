import React from 'react'

function SleeperPage() {
  return (
    <div>
    
    <div className="stearing">
      <img
        className="stearing"
        src="https://cdn-icons-png.flaticon.com/512/2/2087.png"
        alt="stearing"
      />
    </div>
    <div className="seats">
      <img
        className="seat"
        src="https://i.ibb.co/HtJyXS9/seat.png"
        alt="sleeper"
        id="1"
      />
      <img
        className="seat"
        src="https://i.ibb.co/HtJyXS9/seat.png"
        alt="sleeper"
        id="2"
      />
    </div>
    <div className="seats">
      <img
        className="seat"
        src="https://i.ibb.co/HtJyXS9/seat.png"
        alt="sleeper"
        id="1"
      />
      <img
        className="seat"
        src="https://i.ibb.co/HtJyXS9/seat.png"
        alt="sleeper"
        id="2"
      />
    </div>
    <div className="seats">
      <img
        className="seat"
        src="https://i.ibb.co/HtJyXS9/seat.png"
        alt="sleeper"
        id="1"
      />
      <img
        className="seat"
        src="https://i.ibb.co/HtJyXS9/seat.png"
        alt="sleeper"
        id="2"
      />
    </div>
    <div className="seats">
      <img
        className="seat"
        src="https://i.ibb.co/HtJyXS9/seat.png"
        alt="sleeper"
        id="1"
      />
      <img
        className="seat"
        src="https://i.ibb.co/HtJyXS9/seat.png"
        alt="sleeper"
        id="2"
      />
    </div>
    <div className="seats">
      <img
        className="seat"
        src="https://i.ibb.co/HtJyXS9/seat.png"
        alt="sleeper"
        id="1"
      />
      <img
        className="seat"
        src="https://i.ibb.co/HtJyXS9/seat.png"
        alt="sleeper"
        id="2"
      />
    </div>
    </div>
    
  )
}

export default SleeperPage